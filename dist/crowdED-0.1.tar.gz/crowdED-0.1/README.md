Task Optimization Algorithm for Crowdsourcing
====

CrowdED: Task Assignment Optimization Algorithm in Crowdsourcing

[CrowdApp](https://pedrohserrano.shinyapps.io/crowdapp/) Beta

## Preliminary results

![](reports/21wpt10iter.png)
![](reports/100ptrain10iter.png)
![](reports/100tasks10iter.png)
![](reports/100workers10iter.png)
