

library("scales")
show_linetypes(linetype_pal()(3))
show_linetypes(linetype_pal()(3), labels=TRUE)



