###   Charts"


library("scales")
show_col(few_pal()(7))
show_col(few_pal("dark")(7))
show_col(few_pal("light")(7))



