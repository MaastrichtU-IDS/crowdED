

library("ggplot2")
show_shapes(calc_shape_pal()(15))



