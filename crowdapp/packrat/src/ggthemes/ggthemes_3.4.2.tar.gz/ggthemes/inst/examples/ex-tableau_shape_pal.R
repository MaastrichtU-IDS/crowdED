

show_shapes(tableau_shape_pal()(5))



