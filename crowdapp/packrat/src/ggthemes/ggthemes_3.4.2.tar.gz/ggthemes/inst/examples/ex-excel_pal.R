

library("scales")
show_col(excel_pal()(8))
show_col(excel_pal('fill')(8))
show_col(excel_pal('new')(10))



